import logging, tiktoken, nest_asyncio, pickle

nest_asyncio.apply()
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("openai").setLevel(logging.WARNING)
logging.basicConfig(level=logging.WARNING)

import catboost
import numpy as np
import pandas as pd
import yaml, os, json
from PyPDF2 import PdfReader
from llama_index.llms.groq import Groq
from llama_index.llms.openai import OpenAI
from llama_index.core.prompts import Prompt
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core import Settings
from flask import Flask, request, jsonify
from flask_cors import CORS
from db import mongo  # Import mongo from db.py
from controllers.auth_controller import auth_controller
from flask_jwt_extended import JWTManager


app = Flask(__name__)
app.config['CORS_HEADERS'] = 'Content-Type'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['JSON_SORT_KEYS'] = False

app.config["JWT_SECRET_KEY"] = "your-secret-key"  
jwt = JWTManager(app)

app.config['MONGO_URI'] = "mongodb+srv://shanki:1234@cluster0.blzjv.mongodb.net/myDatabase?retryWrites=true&w=majority&appName=Cluster0"
mongo.init_app(app)

CORS(app)


app.register_blueprint(auth_controller, url_prefix='/auth')

with open('artifacts/financial_cls.pkl', 'rb') as f:
    financial_cls = pickle.load(f)

with open('artifacts/operational_cls.pkl', 'rb') as f:
    operational_cls = pickle.load(f)

with open('artifacts/organizational_cls.pkl', 'rb') as f:
    organizational_cls = pickle.load(f)

with open('artifacts/technical_cls.pkl', 'rb') as f:
    technical_cls = pickle.load(f)

embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-small-en-v1.5")

with open('secrets.yaml') as f:
    secrets = yaml.load(f, Loader=yaml.FullLoader)

os.environ["GROQ_API_KEY"] = secrets['GROQ_API_KEY']
os.environ["VOYAGE_API_KEY"] = secrets['VOYAGE_API_KEY']
os.environ["LLAMA_CLOUD_API_KEY"] = secrets['LLAMACLOUD_API_KEY']

# completion_llm = Groq(
#                     model="llama3-70b-8192", 
#                     api_key=os.environ["GROQ_API_KEY"],
#                     temperature=0.5
#                     )
completion_llm = OpenAI(
                    model="gpt-4o", 
                    api_key="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",
                    temperature=0.5
                    )

embed_model = HuggingFaceEmbedding(
                                    model_name="BAAI/bge-small-en",
                                    trust_remote_code=True,
                                    device="cpu"
                                    )
tiktoken_encoder = tiktoken.encoding_for_model("gpt-4o")
Settings.embed_model = embed_model
Settings.llm = completion_llm

finance_entities = [
   "Total",
    "utility costs",
    "hardware cost",
    "Software costs",
    "Budget",
    "Additional Costs",
    "man hours",
    "Project Plan(weeks)",
    "Procedure",
    "Security",
    "Resourses",
    "Investment",
    "Resource Utilization Efficiency (%)",
    "Plan Compliance (%)",
    "Cost Per Resource"
]

technical_entities = [
                'Operating System', 'Application Server', 'Front End', 'Back End',
                'Database', 'Processor', 'Speed', 'RAM', 'SSD', 'Hard Disk', 'Device',
                'Framework', 'Source control tools', 'IDE'
                ]

def inference_finance(
                    sample_json,
                    precedure_dict = {
                                    'Excellent' : 0,
                                    'Modorate' : 1,
                                    'low' : 2,
                                    'Poor' : 3
                                    },
                    security_dict = {
                                    'very high' : 0,
                                    'High' : 1,
                                    'low' : 2,
                                    'Modorate' : 3,
                                    'Moderate' : 4,
                                    'Low' : 5
                                    },
                    class_dict_rev = {
                                    0 : "L1",
                                    1 : "L2",
                                    2 : "L3",
                                    3 : "L4",
                                    4 : "L5"
                                    }
                    ):
    sample = pd.DataFrame(sample_json, index=[0])
    sample['Procedure'] = sample['Procedure'].map(precedure_dict)
    sample['Security'] = sample['Security'].map(security_dict)
    pred = financial_cls.predict(sample)[0]
    return class_dict_rev[int(pred)]

def formatOBJ(result):
    def to_float(val):
        try:
            return float(val) if val not in [None, ""] else 0.0
        except ValueError:
            return 0.0  # Default to 0.0 if conversion fails

    obj = {
        "Total": to_float(result.get("Total", 0)),
        "utility costs": to_float(result.get("utility costs", 0)),
        "hardware cost": to_float(result.get("hardware cost", 0)),
        "Software costs": to_float(result.get("Software costs", 0)),
        "Budget": to_float(result.get("Budget", 0)),
        "Additional Costs": to_float(result.get("Additional Costs", 0)),
        "man hours": to_float(result.get("man hours", 0)),
        "Project Plan(weeks)": to_float(result.get("Project Plan(weeks)", 0)),
        "Procedure": result.get("Procedure", None),  # Keep as string
        "Security": result.get("Security", None),  # Keep as string
        "Resourses": to_float(result.get("Resourses", 0)),
        "Investment": to_float(result.get("Investment", 0)),
        "Resource Utilization Efficiency (%)": to_float(result.get("Resource Utilization Efficiency (%)", 0)),
        "Plan Compliance (%)": to_float(result.get("Plan Compliance (%)", 0)),
        "Cost Per Resource": to_float(result.get("Cost Per Resource", 0))
    }
    
    return obj


def inference_operational(
                        sample_json,
                        answer2id = {
                                'A1' : 0,
                                'A2' : 1,
                                'A3' : 2,
                                'A4' : 3,
                                },
                        id2level = {
                                0 : 'L1',
                                1 : 'L2',
                                2 : 'L3',
                                3 : 'L4'
                                }
                        ):
    
    sample_df = pd.DataFrame([sample_json])
    sample_df = sample_df.replace(answer2id)
    response = operational_cls.predict(sample_df.values)
    level = int(response[0])
    return id2level[level]

def inference_organizational(
                            sample_json,
                            answer2id = {
                                    'A1' : 0,
                                    'A2' : 1,
                                    'A3' : 2,
                                    'A4' : 3,
                                    },
                            id2level = {
                                    0 : 'L1',
                                    1 : 'L2',
                                    2 : 'L3',
                                    3 : 'L4'
                                    }
                            ):
    
    sample_df = pd.DataFrame([sample_json])
    sample_df = sample_df.replace(answer2id)
    response = organizational_cls.predict(sample_df.values)
    level = int(response[0])
    return id2level[level]

def data2query(
                row,
                col_names = [
                            'Operating System', 'Application Server', 'Front End', 'Back End',
                            'Database', 'Processor', 'Speed', 'RAM', 'SSD', 'Hard Disk', 'Device',
                            'Framework', 'Source control tools', 'IDE'
                ]):
    query = {}
    for col in col_names:
        query[col] = row[col]
    row["query"] = f"""{query}"""
    return row

def inference_technical(
                        sample_data,
                        class_dict = {
                                    0 : "L1",
                                    1 : "L2",
                                    2 : "L3"
                                    }
                        ):
    sample_data = pd.DataFrame(sample_data, index=[0])
    sample_data = sample_data.apply(data2query, axis=1)
    X = sample_data['query'].values
    Xemb = embed_model.get_text_embedding_batch(X)
    Xemb = np.array(Xemb)
    pred = technical_cls.predict(Xemb)
    return class_dict[int(pred[0])]

def extract_text_from_pdf(file_path):
    with open(file_path, "rb") as file:
        reader = PdfReader(file)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
        
    TOKEN_COUNT = len(tiktoken_encoder.encode(text))
    print(f"Token count: {TOKEN_COUNT}")
    return text

def extract_entities_from_text(text, entities):
    """Uses the Groq LLM to find specific entities within a text."""
    prompt = f"""
    Extract the following entities from the provided text. If any value is not present, return an empty string:
    Entities: {', '.join(entities)}
    
    Text:
    {text}
    
    Return the results in JSON format.
    """
    response = completion_llm.complete(prompt)
    return response.text

def post_process_output(raw_output):
    index_start = raw_output.find("{")  
    index_end = raw_output.rfind("}") + 1
    raw_output = raw_output[index_start:index_end]
    json_output = json.loads(raw_output)
    return json_output

def financial_extraction(pdf_path):
    text = extract_text_from_pdf(pdf_path)
    extracted_data = extract_entities_from_text(text, finance_entities)
    json_output = post_process_output(extracted_data)
    return json_output

def technical_extraction(pdf_path):
    text = extract_text_from_pdf(pdf_path)
    extracted_data = extract_entities_from_text(text, technical_entities)
    json_output = post_process_output(extracted_data)
    print('extracted_data',extracted_data)
    return json_output

def classify_technical_level(extracted_data):
    """
    Classifies the extracted technical data into L1, L2, or L3.
    """

    # Define key indicators for each level
    L1_criteria = {
        "Operating System": ["Linux Ubuntu"],
        "Application Server": ["Django"],
        "Front End": ["HTML", "CSS", "JavaScript"],
        "Back End": ["Ruby on Rails"],
        "Database": ["MySQL"],
        "Processor": ["Intel i7"],
        "Device": ["Smartphone"],
        "IDE": ["Eclipse"]
    }

    L2_criteria = {
        "Operating System": ["Debian"],
        "Application Server": ["WildFly"],
        "Front End": ["Bootstrap"],
        "Back End": ["Spring Boot"],
        "Database": ["MongoDB"],
        "Processor": ["Intel Core i9"],
        "Device": ["Hybrid Cloud"],
        "IDE": ["VS Code"]
    }

    L3_criteria = {
        "Operating System": ["CentOS"],
        "Application Server": ["JBoss"],
        "Front End": ["Svelte"],
        "Back End": ["Spring Boot"],
        "Database": ["MongoDB"],
        "Processor": ["AMD EPYC"],
        "Device": ["Raspberry Pi"],
        "IDE": ["IntelliJ IDEA"]
    }

    # Count matches for each category
    def match_score(data, criteria):
        score = 0
        for key, values in criteria.items():
            if key in data and any(value in data[key] for value in values):
                score += 1
        return score

    # Get scores
    l1_score = match_score(extracted_data, L1_criteria)
    l2_score = match_score(extracted_data, L2_criteria)
    l3_score = match_score(extracted_data, L3_criteria)

    # Determine classification based on highest score
    scores = {"L1": l1_score, "L2": l2_score, "L3": l3_score}
    predicted_level = max(scores, key=scores.get)

    return predicted_level


@app.route('/fields/financial', methods=['POST'])
def fields_financial():
    data = request.files['file']
    file_name = request.form.get('name')  # Get project name from form data
    email = request.form.get('email')  # Get email from form data

    print(file_name)
    file_path = f"uploads/{data.filename}"
    data.save(file_path)
    output = financial_extraction(file_path)
    print(output, 'output')
    formted_obj = formatOBJ(output)
    print (formted_obj, 'formate')
    result = inference_finance(formted_obj)

    project_data = {
        "file_name": file_name,
        "financial_result": result,
        "email": email
    }

    # Check if project already exists
    existing_project = mongo.db.projects.find_one({"email": email, "file_name": file_name})

    if existing_project:
        # Update existing project
        mongo.db.projects.update_one(
            {"email": email, "file_name": file_name},
            {"$set": {"financial_result": result}}
        )
        return jsonify({"message": "Project updated successfully", "data": project_data}), 200
    else:
        # Insert new project
        mongo.db.projects.insert_one(project_data)
        return jsonify({"message": "Project added successfully", "data": project_data}), 201


@app.route('/fields/technical', methods=['POST'])
def fields_technical():
    data = request.files['file']
    file_name = request.form.get('name')  # Get project name from form data
    email = request.form.get('email')  # Get email from form data
    print(file_name)
    file_path = f"uploads/{data.filename}"
    data.save(file_path)
    output = technical_extraction(file_path)
    classification = classify_technical_level(output)
    result = inference_technical(output)

    project_data = {
        "file_name": file_name,
        "technical_result": classification,
        "email": email
    }

    # Check if project already exists
    existing_project = mongo.db.projects.find_one({"email": email, "file_name": file_name})

    if existing_project:
        # Update existing project
        mongo.db.projects.update_one(
            {"email": email, "file_name": file_name},
            {"$set": {"technical_result": classification}}
        )
        return jsonify({"message": "Project updated successfully", "data": project_data}), 200
    else:
        # Insert new project
        mongo.db.projects.insert_one(project_data)
        return jsonify({"message": "Project added successfully", "data": project_data}), 201


@app.route('/api/finance', methods=['POST'])
def finance():
    data = request.json
    output = inference_finance(data)
    
    return jsonify({"output": output})

@app.route('/api/operational', methods=['POST'])
def operational():
    data = request.json  # Parse JSON body
    if not data:
        return jsonify({"error": "Invalid request, missing data"}), 400

    email = data.get("email")
    file_name = data.get("file_name")
    ans = data.get("ans", {})

    if not email or not file_name:
        return jsonify({"error": "Email and file_name are required"}), 400

    output = inference_operational(ans)

    project_data = {
        "file_name": file_name,
        "operational_result": output,
        "email": email
    }

    existing_project = mongo.db.projects.find_one({"email": email, "file_name": file_name})

    if existing_project:
        # Update existing project
        mongo.db.projects.update_one(
            {"email": email, "file_name": file_name},
            {"$set": {"operational_result": output}}
        )
        return jsonify({"message": "Project updated successfully", "data": project_data}), 200
    else:
        # Insert new project
        mongo.db.projects.insert_one(project_data)
        return jsonify({"message": "Project added successfully", "data": project_data}), 201


@app.route('/api/organizational', methods=['POST'])
def organizational():
    data = request.json  # Parse JSON body
    if not data:
        return jsonify({"error": "Invalid request, missing data"}), 400

    email = data.get("email")
    file_name = data.get("file_name")
    ans = data.get("ans", {})

    if not email or not file_name:
        return jsonify({"error": "Email and file_name are required"}), 400

    output = inference_organizational(ans)

    project_data = {
        "file_name": file_name,
        "organizational_result": output,
        "email": email
    }

    existing_project = mongo.db.projects.find_one({"email": email, "file_name": file_name})

    if existing_project:
        # Update existing project
        mongo.db.projects.update_one(
            {"email": email, "file_name": file_name},
            {"$set": {"organizational_result": output}}
        )
        return jsonify({"message": "Project updated successfully", "data": project_data}), 200
    else:
        # Insert new project
        mongo.db.projects.insert_one(project_data)
        return jsonify({"message": "Project added successfully", "data": project_data}), 201


@app.route('/api/technical', methods=['POST'])
def technical():
    data = request.json
    output = inference_technical(data)
    return jsonify({"output": output})



@app.route('/api/projects', methods=['GET'])
def get_user_projects():
    email = request.args.get("email")  # Get email from query params

    if not email:
        return jsonify({"error": "Email is required"}), 400

    user_projects = list(mongo.db.projects.find({"email": email}, {"_id": 0}))  # Exclude MongoDB _id field

    if not user_projects:
        return jsonify({"message": "No projects found for this user"}), 404

    return jsonify({"projects": user_projects}), 200  

@app.route('/api/projects/delete', methods=['DELETE'])
def delete_project():
    email = request.args.get("email")
    file_name = request.args.get("file_name")

    if not email or not file_name:
        return jsonify({"error": "Both email and file_name are required"}), 400

    # Check if project exists
    project = mongo.db.projects.find_one({"email": email, "file_name": file_name})

    if not project:
        return jsonify({"error": "Project not found"}), 404

    # Delete the project
    mongo.db.projects.delete_one({"email": email, "file_name": file_name})

    return jsonify({"message": f"Project '{file_name}' deleted successfully"}), 200 

if __name__ == '__main__':
    app.run(port=5000, debug=True)