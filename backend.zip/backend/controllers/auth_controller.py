from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash, check_password_hash
from db import mongo  # Import mongo from db.py (prevents circular import)

auth_controller = Blueprint('auth', __name__)

@auth_controller.route("/register", methods=["POST"])
def register():
    data = request.json
    name = data.get("name")
    mobile = data.get("mobile")
    email = data.get("email")
    password = data.get("password")

    if mongo.db.accounts.find_one({"email": email}):
        return jsonify(message="User already exists"), 400

    hashed_password = generate_password_hash(password)
    mongo.db.accounts.insert_one({"email": email, "password": hashed_password, "name": name, "mobile":mobile})

    return jsonify(message="User registered successfully"), 201

@auth_controller.route("/update", methods=["POST"])
def update_profile():
    data = request.json

    previusEmail = data.get("previusEmail")  # Use email to find the user
    email = data.get("email")  # Use email to find the user
    name = data.get("name")
    mobile = data.get("mobile")
    image = data.get("image")

    if not email:
        return jsonify(message="Email is required"), 400

    # Find the user by email
    user = mongo.db.accounts.find_one({"email": previusEmail})
    if not user:
        return jsonify(message="User not found"), 404

    # Prepare the update data
    updated_data = {}
    if name:
        updated_data["name"] = name
    if mobile:
        updated_data["mobile"] = mobile
    if image:
        updated_data["image"] = image

    # Perform the update
    mongo.db.accounts.update_one({"email": email}, {"$set": updated_data})

    return jsonify(message="Profile updated successfully"), 200

@auth_controller.route("/login", methods=["POST"])
def login():
    data = request.json
    email = data.get("email")
    password = data.get("password")

    user = mongo.db.accounts.find_one({"email": email})  # Fetch user

    if not user or not check_password_hash(user["password"], password):
        return jsonify(message="Invalid email or password"), 401

    # Create access token
    access_token = create_access_token(identity=email)

    # Fetch user projects based on email
    user_projects = list(mongo.db.projects.find({"email": email}, {"_id": 0}))  # Exclude _id field

    # Prepare user data
    user_data = {
        "id": str(user["_id"]),
        "name": user.get("name"),
        "email": user.get("email"),
        "mobile": user.get("mobile"),
        "role": user.get("role", "user"),  # Default role if not present
        "projects": user_projects  # Include projects in response
    }

    return jsonify(access_token=access_token, user=user_data), 200

@auth_controller.route("/protected", methods=["GET"])
@jwt_required()
def protected():
    current_user = get_jwt_identity()
    return jsonify(message=f"Hello, {current_user}! You have access."), 200
