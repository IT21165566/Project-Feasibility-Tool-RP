import pickle
import warnings
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from lightgbm import LGBMClassifier
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.metrics import confusion_matrix, classification_report, ConfusionMatrixDisplay
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.feature_selection import SelectFromModel

warnings.filterwarnings('ignore')

def financial_data_pipeline(data_path='data/Operational_Data_New.xlsx'):
    answer2id = {'A1': 0, 'A2': 1, 'A3': 2, 'A4': 3}
    level2id = {'L1': 0, 'L2': 1, 'L3': 2, 'L4': 3}
    df = pd.read_excel(data_path, sheet_name='Sample data')
    df['level'] = df['level'].str.split('-').str[0].str.strip()
    df.replace(answer2id, inplace=True)
    df.replace(level2id, inplace=True)
    
    Y = df['level'].values
    X = df.drop(columns=['level']).values
    Xtrain, Xtest, Ytrain, Ytest = train_test_split(X, Y, test_size=0.2, stratify=Y, random_state=42)
    
    scaler = StandardScaler()
    Xtrain = scaler.fit_transform(Xtrain)
    Xtest = scaler.transform(Xtest)
    
    sm = SMOTE(random_state=42)
    Xtrain, Ytrain = sm.fit_resample(Xtrain, Ytrain)
    
    return Xtrain, Xtest, Ytrain, Ytest

Xtrain, Xtest, Ytrain, Ytest = financial_data_pipeline()

param_grid_rf = {
    'n_estimators': [100, 200, 300],
    'max_depth': [10, 20, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

rf_grid = RandomizedSearchCV(RandomForestClassifier(), param_grid_rf, n_iter=10, cv=5, verbose=2, n_jobs=-1)
rf_grid.fit(Xtrain, Ytrain)
best_rf = rf_grid.best_estimator_

selector = SelectFromModel(best_rf)
selector.fit(Xtrain, Ytrain)
Xtrain = selector.transform(Xtrain)
Xtest = selector.transform(Xtest)

cls = StackingClassifier(
    estimators=[
        ('rf', RandomForestClassifier(n_estimators=200, max_depth=20)),
        ('lgbm', LGBMClassifier(n_estimators=200, max_depth=10))
    ],
    final_estimator=LGBMClassifier(n_estimators=100, max_depth=5)
)

cls.fit(Xtrain, Ytrain)
Ptrain = cls.predict(Xtrain)
Ptest = cls.predict(Xtest)

print("====================== Train CLS REPORT =======================")
print(classification_report(Ytrain, Ptrain, target_names=['L1', 'L2', 'L3', 'L4']))

print("====================== Test CLS REPORT =======================")
print(classification_report(Ytest, Ptest, target_names=['L1', 'L2', 'L3', 'L4']))

cm_train = confusion_matrix(Ytrain, Ptrain)
cm_test = confusion_matrix(Ytest, Ptest)

fig, axes = plt.subplots(1, 2, figsize=(12, 5))
disp_train = ConfusionMatrixDisplay(cm_train, display_labels=['L1', 'L2', 'L3', 'L4'])
disp_train.plot(ax=axes[0], cmap="Blues")
axes[0].set_title("Training Confusion Matrix")

disp_test = ConfusionMatrixDisplay(cm_test, display_labels=['L1', 'L2', 'L3', 'L4'])
disp_test.plot(ax=axes[1], cmap="Blues")
axes[1].set_title("Testing Confusion Matrix")
plt.tight_layout()
plt.show()

with open('artifacts/operational_cls.pkl', 'wb') as f:
    pickle.dump(cls, f)

def predict_level(sample_json):
    answer2id = {'A1': 0, 'A2': 1, 'A3': 2, 'A4': 3}
    id2level = {0: 'L1', 1: 'L2', 2: 'L3', 3: 'L4'}
    sample_df = pd.DataFrame([sample_json]).replace(answer2id)
    sample_df = selector.transform(sample_df.values)
    response = cls.predict(sample_df)
    return id2level[int(response[0])]

sample_json = {f'Q{i+1}': 'A1' for i in range(20)}
predict_level(sample_json)